<?php

namespace App\Observers;

class ProductObserver
{

}
