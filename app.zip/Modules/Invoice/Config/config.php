<?php

return [
    'name' => 'Invoice'
];
