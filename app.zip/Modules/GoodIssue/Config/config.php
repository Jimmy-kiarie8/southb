<?php

return [
    'name' => 'GoodIssue'
];
