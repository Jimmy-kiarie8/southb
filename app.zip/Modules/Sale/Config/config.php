<?php

return [
    'name' => 'Sale'
];
